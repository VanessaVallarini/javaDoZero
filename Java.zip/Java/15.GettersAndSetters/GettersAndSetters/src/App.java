import java.time.Period;

import modelos.Pessoa;

public class App {
    public static void main(String[] args) throws Exception {
        
        Pessoa pessoaA = new Pessoa();
        pessoaA.setNome("Vanessa");
        System.out.println("Nome: " + pessoaA.getNome());

        /**
         * Boas práticas
            É melhor deixar o set apenas para operação simples de setar.
            Para operações mais complexas, que envolvam validações é 
            recomendado criar um método diferente de set.
         */

    }
}
