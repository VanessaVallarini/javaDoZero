/**
 * 1.Arquivo-java
 */
public class ArquivoJava {

    /*Tudo o que está dentro do main será executado primeiro*/
    public static void main(String[] args) {

        System.out.println("Arquivo Java");

    }
    
}