public class App {
    public static void main(String[] args) throws Exception {
        
        Personagem personagemA = new Personagem();
        personagemA.nome = "Hércules";
        personagemA.nivel = 2;
        personagemA.forca = 16;

        personagemA.mostrarStatus();
        personagemA.atacar("Goku");

    }
}
