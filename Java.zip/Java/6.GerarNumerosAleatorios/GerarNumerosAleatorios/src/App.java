import java.util.Random;

import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) throws Exception {

        double numeroRandomico = Math.random();
        double numeroRandomicoComIntervaloMaximo = Math.random() * 2;
        int numeroRandomicoComIntervaloMinimoEMaximo = 1 + (int) (Math.random() * 3);

        //usando a classe
        Random gerador = new Random();
        int result = gerador.nextInt(100) + 2; //entre 2 e 100
        int result2 = 2 + gerador.nextInt(100); //entre 2 e 100

        JOptionPane.showMessageDialog(null, numeroRandomico, "Número Randômico", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, numeroRandomicoComIntervaloMaximo, "Número Randômico Com Intervalo Máximo de 1", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, numeroRandomicoComIntervaloMinimoEMaximo, "Número Randômico Com Intervalo Mínimo de 1 e Máximo de 3", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, result, "Número Randômico Com Intervalo Mínimo de 2 e Máximo de 100", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, result2, "Número Randômico Com Intervalo Mínimo de 2 e Máximo de 100", JOptionPane.INFORMATION_MESSAGE);

        /*  
            BOAS PRÁTICAS

            * Usar a classe Random ao invés de Math.random
            * Para testar seu código evite gerar números aleatórios toda vez que executar seu algoritmo 
              inserindo um parâmetro para gerar m determinado valor sempre: Random gerador = new Random(9);
        */
    }
}
