import java.util.Arrays;

import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) throws Exception {
        
        String[] nomes = new String[5];
        nomes[0] = "Fábio";
        nomes[1] = "Vanessa";
        nomes[2] = "Maria";
        nomes[3] = "Flavis";
        nomes[4] = "Luiz";
        for(int cont = 0; cont < nomes.length; cont++){
            System.out.format("Nome: %s \n", nomes[cont]);
        }

        System.out.println();

        String[] nomes2 = new String[] {
            "Fábio", "Vanessa", "Maria", "Flavis", "Luiz"
        };
        for(int cont = 0; cont < nomes2.length; cont++){
            System.out.format("Nome2: %s \n", nomes2[cont]);
        }

        System.out.println();

        int[] numeros = new int[5];
        Arrays.fill(numeros, 0); //preenche todo o array com um determinado valor
        System.out.format(Arrays.toString(numeros));

        System.out.println();

        String[] opcoes = new String[]{
            "Anime HunterXHunter",//0
            "Série Game of Thrones",//1
            "Filme Vingadores",//2
            "Sair"//3
        };
        int opcaoEscolhida = 0;
        while(opcaoEscolhida != 3){
            opcaoEscolhida = JOptionPane.showOptionDialog(
                null, 
                "O que você deseja assistir?", 
                "DevFlix", 
                JOptionPane.DEFAULT_OPTION, 
                JOptionPane.QUESTION_MESSAGE, 
                null, 
                opcoes, 
                0
            );

            if(opcaoEscolhida != 3){
                String mensagem = "Você assistiu " + opcoes[opcaoEscolhida];
                JOptionPane.showMessageDialog(null, mensagem);
            }

        }

    }
}
