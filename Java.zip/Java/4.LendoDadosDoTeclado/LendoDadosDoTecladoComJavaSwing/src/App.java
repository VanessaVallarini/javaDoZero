import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) throws Exception {
        
        String jogo = JOptionPane.showInputDialog(
                        null,
                        "Qual o seu jogo do momento?", 
                        "Título", 
                        JOptionPane.QUESTION_MESSAGE);

        String numeroInteiro = JOptionPane.showInputDialog(
                            null,
                            "Digite um número inteiro: ");
        int numeroInteiroConvertido = Integer.parseInt(numeroInteiro);
        numeroInteiroConvertido = numeroInteiroConvertido * 10;

        JOptionPane.showMessageDialog(
                            null,
                            "Jogo: " + jogo);
        JOptionPane.showMessageDialog(
                            null,
                            "Número * 10 = " + numeroInteiroConvertido);        

    }
}
