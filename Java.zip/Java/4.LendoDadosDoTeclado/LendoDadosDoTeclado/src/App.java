import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        
        int numeroInteiro;
        float numeroFloat;
        String jogo;
        String jogo2;

        //o leitor é declarado apenas 1 vez
        Scanner leitor = new Scanner(System.in);

        System.out.print("Digite um número inteiro: ");
        numeroInteiro = leitor.nextInt();
        System.out.println("Número inteiro é " + numeroInteiro);

        System.out.println();
        System.out.print("Digite um número float: ");
        numeroFloat = leitor.nextFloat();
        System.out.println("Número float é " + numeroFloat);

        System.out.println();
        System.out.print("Qual o seu jogo do momento?");
        jogo = leitor.next();
        System.out.println("O jogo é " + jogo); //league of legends ficou apenas league

        //o leitor é declarado apenas 1 vez
        //o espaço em branco não é mais um separador
        //separadores podem ser espaço em branco, ex:
        //league of legends ou league            of legends (isso é o sinal de + quem dita)
        Scanner leitor2 = new Scanner(System.in);
        leitor2.useDelimiter("[\r\n]+");

        System.out.println();
        System.out.print("Qual o seu jogo do momento?");        
        jogo2 = leitor2.next();
        System.out.println("O jogo é " + jogo2);

        System.out.println();
        /* 
            BOAS PRÁTICAS NA LEITURA DE DADOS

            Leia todos os dados como string e os converta

         */

        int horasATrabalhar = 8;
        int horasTrabalhadas;
        String valorEntrada;

        Scanner leitorString = new Scanner(System.in);

        System.out.print("Digite as horas trabalhadas: ");
        valorEntrada = leitorString.nextLine(); //pode ser tb leitorString.next();
        horasTrabalhadas = Integer.parseInt(valorEntrada);

        System.out.println("Quantas horas ainda preciso trabalhar: " + (horasATrabalhar - horasTrabalhadas));

    }
}
