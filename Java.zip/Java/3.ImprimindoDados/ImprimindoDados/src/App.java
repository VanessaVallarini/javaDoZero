public class App {
    public static void main(String[] args) throws Exception {
        
        String filme = "Vingadores";
        int anoLancamento = 2015;
        int duracao = 240;
        float notaCritica = 8.7f;
        char letraInicial = 'V';
        boolean foiSucesso = true;

        System.out.println(filme);
        System.out.println(anoLancamento);
        System.out.println(duracao);
        System.out.println(notaCritica);
        System.out.println(letraInicial);
        System.out.println(foiSucesso);

        System.out.println();

        System.out.println("Filme: " + filme);
        System.out.println("Ano lançamento: " + anoLancamento);
        System.out.println("Duração: " + duracao);
        System.out.println("Nota crítica: " + notaCritica);
        System.out.println("Letra inicial: " + letraInicial);
        System.out.println("Foi sucesso? " + foiSucesso);

        System.out.println();

        System.out.println("O filme " + filme + " lançado em " + anoLancamento
                            + " tem duração de " + duracao + " minutos");

        System.out.println();
        /*
            String: %s
            Int: %d
            Float: %f
            Double: %f
            Char: %c
            Boolean: %b
         */
        System.out.format("O filme %s lançado em %d tem duração de %d minutos",
                                filme, anoLancamento, duracao);
        String textoFormat = String.format("O filme %s lançado em %d tem duração de %d minutos",
                                            filme, anoLancamento, duracao);
        System.out.println();
        System.out.println();
        System.out.println(textoFormat);

        System.out.println();
        System.err.println("Imprimindo mensagem em formato de erro");

        System.out.println();
        System.out.println("Pulando\n uma linha");
        System.out.println();
        System.out.println("Pulando\n\n duas linha");
    }
}
