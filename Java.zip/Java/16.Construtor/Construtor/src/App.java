import classes.Pessoa;

public class App {
    public static void main(String[] args) throws Exception {
        
        //Pessoa pessoaA = new Pessoa();
        //pessoaA.setNome("Vanessa");
        //pessoaA.setIdade(30);
        //pessoaA.setAltura(1.68f);

        Pessoa pessoaA = new Pessoa("Vanessa", 30, 1.68f);

        System.out.format("Nome: %s, Idade: %d, Altura: %.2f\n", 
                                pessoaA.getNome(),
                                pessoaA.getIdade(),
                                pessoaA.getAltura()
                            );

        pessoaA.setNome("Van");

        System.out.format("Nome: %s, Idade: %d, Altura: %.2f\n", 
                                pessoaA.getNome(),
                                pessoaA.getIdade(),
                                pessoaA.getAltura()
                            );

        /**
         * Boas práticas
            - Sempre que criar uma classe siga a ordem:
                1. Criar variáveis
                2. Criar construtor (evite usar muitos parâmetros de entrada)
                3. Criar métodos específicos (evite usar muitos parâmetros de entrada)
                4. Criar getters e setters 
         */
    }
}
