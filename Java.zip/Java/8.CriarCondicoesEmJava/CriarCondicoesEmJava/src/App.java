public class App {
    public static void main(String[] args) throws Exception {
        
        boolean estaChovendo = true;
        boolean naoTemGuardachuva = true;

        if(estaChovendo){
            System.out.println("Está chovendo!");
        }

        if(estaChovendo && naoTemGuardachuva){
            System.out.println("Está chovendo e não tem guardachuva!");
        }

        if(estaChovendo || naoTemGuardachuva){
            System.out.println("Está chovendo ou não tem guardachuva!");
        }

        if(!estaChovendo){
            System.out.println("Não está chovendo ou não tem guardachuva!");
        } else {
            System.out.println("Está chovendo!");
        }

        if(!estaChovendo){
            System.out.println("Não está chovendo ou não tem guardachuva!");
        } else if (naoTemGuardachuva){
            System.out.println("Tem guardachuva");
        } else{
            System.out.println("Não tem guardachuva");
        }

        //Operador ternário (if else em uma única linha)
        String video = "HunterXHunter";
        String categoria = (video == "HunterXHunter") ? "anime" : "série";
        System.out.println(categoria);

    }
}
