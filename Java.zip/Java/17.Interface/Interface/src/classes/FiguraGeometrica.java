package classes;

public interface FiguraGeometrica {
    public double calcularArea();
}
