package classes;

public class Circulo implements FiguraGeometrica{

    //Atributos
    private int raio;

    //Construtor
    public Circulo(int raio){
        this.raio = raio;
    }

    //Métodos específicos
    @Override
    public double calcularArea() {
        return Math.PI * Math.pow(raio, 2);
    }

    //Métodos Gettes e Setters
    /**
     * @return int return the raio
     */
    public int getRaio() {
        return raio;
    }

    /**
     * @param raio the raio to set
     */
    public void setRaio(int raio) {
        this.raio = raio;
    }

}