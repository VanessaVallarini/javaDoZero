public class App {

    /*Variável, o que é? 
        É um dado salvo na memória do meu computador e poderei usála/alterála 
        como eu quiser no decorrer do meu programa
    */
    /*Variável, quanto de espaço ocupam na memória? 
        Variáveis do tipo primitiva ocupam um espaço fixo na memória.
        Elas são: Inteiros, ponto flutuante, caractere e booleanos
    */
    public static void main(String[] args) throws Exception {

        System.out.println("INTEIROS");
        System.out.println();
        /*
            Inteiros (menor para o maior)

            Byte: armazena valores entre -128 e 127
            Short: vai de -32768 a 32767
            Int: vai de -2147483648 a 2147483647
            Long: vai de -9223372036854775808L e 9223372036854775807L 
        */
        
        byte numeroByte = 127;
        System.out.println("Byte:" + numeroByte);

        short numeroShort = 32767;
        System.out.println("Short:" + numeroShort);

        int numeroInt = 2147483647;
        System.out.println("Int:" + numeroInt);

        long numeroLong = 9223372036854775807l;
        System.out.println("Long:" + numeroLong);


        System.out.println();
        System.out.println();
        System.out.println("PONTO FLUTUANTE");
        System.out.println();
        /*
            Ponto Flutuante

            Float: armazena valores com casas decimais
            Double: armazena valores com muitos números após a vírgula
             
        */
        
        float numeroFloat = 78.7f;
        System.out.println("Float:" + numeroFloat);

        double numeroDouble = 3.14159265359;
        System.out.println("Double:" + numeroDouble);



        System.out.println();
        System.out.println();
        System.out.println("CARACTERE");
        System.out.println();
        /*
            Caractere

            Char: armazena um único caractere
            String: armazena strings e não é do tipo primitiva, pois
            ocupa o espaço na memória de acordo com o tamanho da string.
            E por isso ela inicia com o S maiúcuclo, pois, é considerada
            uma variável do tipo classe.
             
        */
        
        char caractereChar = 'a';
        System.out.println("Char:" + caractereChar);

        String texto = "Finalmente serei Javera ushushus";
        System.out.println("String:" + texto);



        System.out.println();
        System.out.println();
        System.out.println("BOOBLEANA");
        System.out.println();
        /*
            Booleana

            Armazena verdadeiro ou falso
             
        */
        
        boolean booleanTrue = true;
        System.out.println("BooleanTrue:" + booleanTrue);

        boolean booleanFalse = false;
        System.out.println("BooleanFalse:" + booleanFalse);

        /*
            Boas práticas

            * Não usar nomes reservados do java para nomes de variáveis, ex: public
            * camelCase é o padrão mais usado: minhaVariavel
            * case-sensitive: nome é diferente de Nome
             
        */
    }
}
