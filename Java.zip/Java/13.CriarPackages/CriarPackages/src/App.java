import br.com.devflix.gui.Janela;
import br.com.devflix.gui.MiniaturaVideo;
import br.com.devflix.videos.Anime;
import br.com.devflix.videos.Documentario;
import br.com.devflix.videos.Filme;
import br.com.devflix.videos.Novela;
import br.com.devflix.videos.Serie;

public class App {
    public static void main(String[] args) throws Exception {
        
        Anime anime = new Anime();
        Documentario documentario = new Documentario();        
        Filme filme = new Filme();
        Novela novela = new Novela();
        Serie serie = new Serie();
        Janela janela = new Janela();
        MiniaturaVideo miniaturaVideo = new MiniaturaVideo();

        /**
         * Boas práticas:
         * 
            Os pacotes externos costumam ter nomenclaturas seguindo o exemplo: 
             - br.com.localizacao.brasil.Gps
               1º pega o domínio: DevFlix - www.devflix.com.br
               2º inverte o domínio: br.com.devflix
               3º estrutura:
                            br/
                                com/
                                    devflix/
                                        video (packages)
                                        gui (packages)

            O mesmo pacote acima interno ao meu projeto seria:
             - <projeto>.<classe>
             - localizacao.Gps
         */
    }
}
