package br.com.devflix.gui;

public class MiniaturaVideo {
    
}