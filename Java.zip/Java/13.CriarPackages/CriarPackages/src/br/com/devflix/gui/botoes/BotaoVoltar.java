package br.com.devflix.gui.botoes;

public class BotaoVoltar {
    
}
