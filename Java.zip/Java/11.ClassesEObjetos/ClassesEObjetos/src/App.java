public class App {
    public static void main(String[] args) throws Exception {
        
        Celular celularA = new Celular();
        celularA.nome = "Iphone 12";
        celularA.sistemaOperacional = "iOS";
        celularA.espacoArmazenamento = 256;
        celularA.tamanhoTela = 6.1f;
        System.out.format(
            "Celular A \nNome: %s \nSistema operacional: %s \nEspaço armazenamento: %dgb \nTamanho tela: %.1f",
            celularA.nome, celularA.sistemaOperacional, celularA.espacoArmazenamento, celularA.tamanhoTela);
    }
}
