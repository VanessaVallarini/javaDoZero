public class App {
    public static void main(String[] args) throws Exception {
        
        int contadorWhile = 0;
        while(contadorWhile < 3){
            System.out.format("While contador < 3: %d \n", contadorWhile);
            contadorWhile++;
        }

        System.out.println();

        String nome = "Maria";
        do{
            System.out.format("Nome não é Vanessa, porém, a verificação é feita no final: %s \n", nome);
            
        } while(nome == "Vanessa");
        
        System.out.println();
        int contadorFor;
        for(contadorFor = 0; contadorFor <= 3; contadorFor++){
            System.out.format("Contador for <= 100: %d \n", contadorFor);
        }
    }
}
