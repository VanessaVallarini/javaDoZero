public class FestaVip {

    private int quantidadeCafe = 30;
    private int quantidadeSalgado = 90;

    //aqui poderia ser o construtor
    public void entrar(String convite){
        if(convite.equals("Premium")){
            quantidadeCafe = 60;
            quantidadeSalgado = 180;
        } else{
            quantidadeCafe = 30;
            quantidadeSalgado = 90;
        }        
    }

    private void statusCafe(){
        System.out.format("Você ainda possui %d xícaras de café.\n", quantidadeCafe);
    }

    private void statusSalgado(){
        System.out.format("Você ainda possui %d qtd de salgados.\n", quantidadeSalgado);
    }

    public void beberCafe(){
        quantidadeCafe--;
        statusCafe();
    }

    public void comerSalgado(){
        quantidadeSalgado = quantidadeSalgado - 5;
        statusSalgado();
    }

}
