public class App {
    public static void main(String[] args) throws Exception {
        
        /**
         * Tipos de visibilidade:
            private
            public
            protected
            default: privado para as classes que estão em pacotes/packages diferentes
                     e público para as classes que estão dentro do mesmo pacote/package
         */

        FestaVip festaVip = new FestaVip();

        festaVip.entrar("convite");
        festaVip.beberCafe();
        festaVip.comerSalgado();

        /**
         * Boas práticas:
            - Em atributos de classes geralmente usamos o modificador private
            - Sempre usar o modificador de acesso
         */

    }
}
