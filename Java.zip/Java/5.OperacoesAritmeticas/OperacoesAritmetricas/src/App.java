import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) throws Exception {
        
        int numeroA = 6;
        int numeroB = 5;

        int soma = numeroA + numeroB;
        int subtracao = numeroA - numeroB;
        int multiplicacao = numeroA * numeroB;
        double divisao = (double) numeroA / numeroB;
        int restoDivisao = numeroA % numeroB;

        //incrementa + 1. 
        //Pode ser tb 
        //incrementar maior que 1:  int incrementar += 10;
        //decrementar maior que 1:  int incrementar -= 2;
        //Pode ser tb por multiplicação: int incrementar *= 10;
        //++numeroA vs numeroA++: o primeiro altera o valor antes de imprimir. O segundo imprime e depois altera o valor
        int incrementar = ++numeroA; 
        int decrementar = --numeroA; 

        /*
            Precedência na matemática, da maior pra menor:

            Parênteses;
            Expoentes;
            Multiplicações e divisões; (da esquerda para a direita);
            Somas e subtrações. (da esquerda para a direita);

         */
        int procedenciaMatematica1 = 8 + 9 * 2; // 26
        int procedenciaMatematica2 = (8 + 9) * 2; // 34

        /*  Funções Math */
        int numeroANegativo = -6;
        int numeroAbsoluto = Math.abs(numeroANegativo); //retorna o positivo
        double numeroElevadoAOutro = (double) Math.pow(10, 2);
        double raizQuadrada = Math.sqrt(4);
        double arredondarPraCima = Math.ceil(12.8);
        double arredondarPraBaixo = Math.floor(12.5);
        int minimo = Math.min(numeroA, numeroB);
        int maximo = Math.max(numeroA, numeroB);
 
        JOptionPane.showMessageDialog(null, soma, "Soma", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, subtracao, "Subtração", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, multiplicacao, "Multiplicacao", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, divisao, "Divisao", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, restoDivisao, "Resto Divisao", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, incrementar, "Incrementar", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, decrementar, "Decrementar", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, procedenciaMatematica1, "Procedencia Matematica 1", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, procedenciaMatematica2, "Procedencia Matematica 2", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, numeroAbsoluto, "Número Absoluto", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, numeroElevadoAOutro, "Número Elevado A Outro", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, raizQuadrada, "Raiz Quadrada", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, arredondarPraCima, "Arredondar Pra Cima", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, arredondarPraBaixo, "Arredondar Pra Baixo", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, minimo, "Mínimo", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, maximo, "Máximo", JOptionPane.INFORMATION_MESSAGE);

    }
}
