import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) throws Exception {
             
        /*
            Operadores relacionais

            > maior que
            < menor que
            >= maior ou igual a
            <= menor ou igual a 
            == igual a 
            != diferente de
        */

        int idade = 2;
        boolean resultado = idade >= 18;
        JOptionPane.showMessageDialog(null, resultado, "Idade maior que 18?", JOptionPane.INFORMATION_MESSAGE);


        /*
            Operadores lógicos

            && AND
            || OR
            ! NOT
        */

        String usuario = "vanessa-ichikawa";
        String senha = "40028922";
        
        String usuarioDigitado = "joao";
        String senhaDigitada = "1234";

        boolean loginCorreto = usuario == usuarioDigitado && senha == senhaDigitada;
        boolean loginCorretoNegacao = !(usuario == usuarioDigitado && senha == senhaDigitada);

        JOptionPane.showMessageDialog(null, loginCorreto, "Login", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, loginCorretoNegacao, "Login (negação)", JOptionPane.INFORMATION_MESSAGE);

        /*
            Resumo dos operadores lógicos

            A       B       A && B      A || B
            true    false   false       true
            true    true    true        true
            false   false   false       false
            false   true    false       true
        */

    }
}
